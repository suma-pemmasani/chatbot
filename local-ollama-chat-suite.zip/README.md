# 🦙 Ollama Local Chatbot (Streamlit + Ollama Python SDK)

A production-ready full-stack Chatbot web application featuring a ChatGPT-style UI and a local AI engine offering unlimited, token-free, and 100% private interactions using Ollama.

## 🚀 Quickstart

### 1. Install & Start Ollama
Download and install Ollama from [ollama.com](https://ollama.com).
```bash
# Verify installation
ollama --version

# Pull your preferred models
ollama pull llama3
ollama pull mistral
ollama pull phi3

# Ensure Ollama service is running (default port 11434)
ollama serve
```

### 2. Set Up Python Environment
```bash
# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Launch Streamlit Application
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

## 🛠️ Features Included
- **ChatGPT-Style UI**: Message bubbles with distinct user/assistant avatars, streaming tokens with cursor, pinned bottom chat input, responsive design.
- **Dynamic Model Selector**: Automatic discovery of installed models using `ollama.list()`.
- **System Prompt Customization**: Live personality switching (Python Mentor, Senior Code Reviewer, Concise Assistant, or Custom).
- **Multi-Turn Context**: Preserves full conversation history via `st.session_state.messages` and feeds the structured `messages` array to `ollama.chat`.
- **Error Handling**: Graceful fallback and guides when Ollama daemon is offline or when a model needs to be pulled.
- **Export**: 1-click JSON export of full conversation logs and configuration.
