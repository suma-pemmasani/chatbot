"""
================================================================================
Production-Ready Local Chatbot Web Application
Stack: Streamlit (Python) + Ollama (Python SDK) + python-dotenv
Features:
  - Dynamic ChatGPT-style Chat UI with User and Assistant messaging bubbles
  - Local AI engine via Ollama Python SDK with zero token costs and 100% privacy
  - Dynamic model discovery from local Ollama daemon (e.g., llama3, mistral, phi3)
  - Real-time streaming response generation
  - Multi-turn conversation memory preserved via Streamlit session state
  - System prompt customization with instant role-play presets (e.g., Python Mentor)
  - Comprehensive error handling for daemon offline or missing model states
================================================================================
"""

import os
import json
import logging
from typing import List, Dict, Any, Generator
import streamlit as st
import ollama
from dotenv import load_dotenv

# Load environment variables if configured in .env (e.g. OLLAMA_HOST)
load_dotenv()

# Configure basic logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# -----------------------------------------------------------------------------
# 1. Page Configuration & Custom CSS (ChatGPT-Inspired Aesthetics)
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="Ollama Local Chatbot",
    page_icon="🦙",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling for ChatGPT-style UI
CUSTOM_CSS = """
<style>
    /* Main container styling */
    .main .block-container {
        max-width: 900px;
        padding-top: 2rem;
        padding-bottom: 6rem;
    }

    /* Header title aesthetics */
    .app-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 1rem;
        border-bottom: 1px solid rgba(128, 128, 128, 0.2);
        margin-bottom: 1.5rem;
    }
    
    .app-title {
        font-size: 1.5rem;
        font-weight: 700;
        letter-spacing: -0.02em;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .app-subtitle {
        font-size: 0.85rem;
        color: #888888;
        margin-top: 0.2rem;
    }

    /* Status indicator */
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.2rem 0.6rem;
        border-radius: 9999px;
        background: rgba(16, 185, 129, 0.1);
        color: #10b981;
        border: 1px solid rgba(16, 185, 129, 0.25);
    }
    
    .status-badge-err {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.25);
    }

    .status-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background-color: currentColor;
    }

    /* Chat bubble enhancements */
    .stChatMessage {
        border-radius: 12px;
        padding: 0.75rem 1rem;
        margin-bottom: 0.75rem;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    }

    /* Sidebar controls */
    .sidebar-section-title {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-weight: 700;
        color: #888;
        margin-top: 1.25rem;
        margin-bottom: 0.5rem;
    }

    /* Pinned chat input styling */
    .stChatFloatingInputContainer {
        bottom: 1.5rem;
    }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


# -----------------------------------------------------------------------------
# 2. Session State Initialization
# -----------------------------------------------------------------------------
# Multi-turn conversation messages: list of {"role": "user"|"assistant", "content": "..."}
if "messages" not in st.session_state:
    st.session_state.messages = []

# Active system prompt (personality & behavioral instructions)
DEFAULT_SYSTEM_PROMPT = (
    "You are a helpful, brilliant, and precise AI assistant running locally via Ollama. "
    "Provide clear, accurate, and insightful answers with properly formatted code blocks where applicable."
)

if "system_prompt" not in st.session_state:
    st.session_state.system_prompt = DEFAULT_SYSTEM_PROMPT

# Default parameters
if "temperature" not in st.session_state:
    st.session_state.temperature = 0.7


# -----------------------------------------------------------------------------
# 3. Ollama Client & Dynamic Model Discovery
# -----------------------------------------------------------------------------
@st.cache_data(ttl=5)
def fetch_available_models() -> tuple[List[str], bool, str]:
    """
    Connect to local Ollama daemon and query the list of locally pulled models.
    Returns:
        tuple (models_list, is_connected, error_message)
    """
    try:
        # Check environment variable for remote/custom Ollama host if set
        ollama_host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
        client = ollama.Client(host=ollama_host)
        response = client.list()
        
        # Ollama SDK returns either a dict with 'models' key or objects with attributes
        raw_models = response.get("models", []) if isinstance(response, dict) else getattr(response, "models", [])
        
        model_names = []
        for m in raw_models:
            if isinstance(m, dict):
                name = m.get("model") or m.get("name")
            else:
                name = getattr(m, "model", None) or getattr(m, "name", None)
            
            if name:
                model_names.append(name)
        
        if not model_names:
            return (
                ["llama3:latest", "mistral:latest", "phi3:latest"],
                True,
                "Connected to Ollama, but no models found locally. Run `ollama pull <model>` to download one."
            )
        
        return (sorted(model_names), True, "")
    except Exception as exc:
        err_msg = str(exc)
        logger.warning("Failed to connect to local Ollama daemon: %s", err_msg)
        fallback_models = ["llama3:latest", "mistral:latest", "phi3:latest", "deepseek-r1:latest"]
        return (fallback_models, False, err_msg)


# -----------------------------------------------------------------------------
# 4. Sidebar Controls & Customization
# -----------------------------------------------------------------------------
with st.sidebar:
    st.markdown("### 🦙 Ollama Local Engine")
    st.caption("Unlimited, 100% private, token-free AI on your hardware.")

    # Model Discovery & Connection Status
    available_models, is_ollama_connected, conn_error = fetch_available_models()

    if is_ollama_connected:
        st.markdown(
            '<div class="status-badge"><span class="status-dot"></span>Ollama Active (Local)</div>',
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            '<div class="status-badge status-badge-err"><span class="status-dot"></span>Ollama Disconnected</div>',
            unsafe_allow_html=True
        )
        st.warning(
            "⚠️ **Ollama is not running locally!**\n\n"
            "Please start the service in your terminal:\n"
            "```bash\nollama serve\n```\n"
            "Ensure Ollama is installed from [ollama.com](https://ollama.com)."
        )

    st.markdown('<div class="sidebar-section-title">Model Selector</div>', unsafe_allow_html=True)
    
    # Model selection dropdown
    selected_model = st.selectbox(
        "Active Model:",
        options=available_models,
        index=0,
        help="Select any local model available in your Ollama library."
    )

    # System Prompt Customization
    st.markdown('<div class="sidebar-section-title">System Persona</div>', unsafe_allow_html=True)
    st.caption("Customize chatbot personality and instruction guidelines.")

    # Quick preset selection
    prompt_presets = {
        "Custom": st.session_state.system_prompt,
        "Python Mentor": (
            "You are a Senior Python Architect and friendly coding mentor. "
            "Explain Python concepts concisely with PEP-8 compliant code examples, "
            "highlight best practices, type annotations, and edge cases."
        ),
        "Code Reviewer": (
            "You are a meticulous Senior Software Engineer conducting a thorough code review. "
            "Critique code for performance, security vulnerabilities, readability, and idiomatic style. "
            "Provide refactored code snippets with explanations."
        ),
        "Concise Tech Assistant": (
            "You are an ultra-concise technical assistant. "
            "Answer directly with minimal preamble. Prioritize bullet points, shell commands, and copy-pasteable code."
        ),
        "General Assistant": DEFAULT_SYSTEM_PROMPT
    }

    preset_choice = st.selectbox(
        "Load Preset Persona:",
        options=list(prompt_presets.keys()),
        index=0
    )

    if preset_choice != "Custom":
        st.session_state.system_prompt = prompt_presets[preset_choice]

    system_prompt_input = st.text_area(
        "System Instructions:",
        value=st.session_state.system_prompt,
        height=130,
        help="These instructions are passed to Ollama on each turn to steer response behavior."
    )
    # Sync edited text area back to session state
    st.session_state.system_prompt = system_prompt_input

    # Generation Parameters
    st.markdown('<div class="sidebar-section-title">Generation Parameters</div>', unsafe_allow_html=True)
    temperature = st.slider(
        "Temperature (Creativity):",
        min_value=0.0,
        max_value=1.0,
        value=st.session_state.temperature,
        step=0.05,
        help="0.0 = Deterministic and precise. 1.0 = Creative and exploratory."
    )
    st.session_state.temperature = temperature

    # Action Buttons: Clear Chat & Export
    st.markdown('<div class="sidebar-section-title">Session Management</div>', unsafe_allow_html=True)
    
    col_clear, col_refresh = st.columns(2)
    with col_clear:
        if st.button("🗑️ Clear Chat", use_container_width=True):
            st.session_state.messages = []
            st.rerun()

    with col_refresh:
        if st.button("🔄 Refresh Models", use_container_width=True):
            st.cache_data.clear()
            st.rerun()

    # Conversation Export
    if st.session_state.messages:
        chat_export_json = json.dumps(
            {
                "model": selected_model,
                "system_prompt": st.session_state.system_prompt,
                "messages": st.session_state.messages
            },
            indent=2
        )
        st.download_button(
            label="📥 Export Chat (JSON)",
            data=chat_export_json,
            file_name="ollama_chat_history.json",
            mime="application/json",
            use_container_width=True
        )


# -----------------------------------------------------------------------------
# 5. Main UI Header
# -----------------------------------------------------------------------------
col_header_left, col_header_right = st.columns([3, 1])

with col_header_left:
    st.markdown(
        f"""
        <div class="app-header">
            <div>
                <h1 class="app-title">🦙 Ollama Local Chat</h1>
                <div class="app-subtitle">
                    Active Model: <strong>{selected_model}</strong> · Multi-turn context enabled · Zero API tokens
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

with col_header_right:
    msg_count = len(st.session_state.messages)
    st.metric(label="Conversation Turns", value=msg_count)


# -----------------------------------------------------------------------------
# 6. Render Existing Conversation History (Multi-turn persistence)
# -----------------------------------------------------------------------------
for msg in st.session_state.messages:
    role = msg.get("role", "user")
    content = msg.get("content", "")
    avatar = "🧑‍💻" if role == "user" else "🦙"
    
    with st.chat_message(role, avatar=avatar):
        st.markdown(content)


# -----------------------------------------------------------------------------
# 7. Helper: Build Message Payload with Multi-Turn Context & System Prompt
# -----------------------------------------------------------------------------
def build_ollama_payload(messages_history: List[Dict[str, str]], system_prompt: str) -> List[Dict[str, str]]:
    """
    Constructs the full messages array required by ollama.chat.
    Prepends the active system prompt and appends all previous user and assistant turns.
    """
    payload: List[Dict[str, str]] = []
    
    if system_prompt and system_prompt.strip():
        payload.append({
            "role": "system",
            "content": system_prompt.strip()
        })
        
    for msg in messages_history:
        payload.append({
            "role": msg["role"],
            "content": msg["content"]
        })
        
    return payload


def stream_ollama_response(
    model: str,
    messages_payload: List[Dict[str, str]],
    temp: float
) -> Generator[str, None, None]:
    """
    Streams tokens in real time from Ollama using the Python SDK.
    Yields chunks of text as they arrive.
    """
    ollama_host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    client = ollama.Client(host=ollama_host)
    
    response_stream = client.chat(
        model=model,
        messages=messages_payload,
        stream=True,
        options={
            "temperature": temp
        }
    )
    
    for chunk in response_stream:
        content_piece = ""
        if isinstance(chunk, dict):
            content_piece = chunk.get("message", {}).get("content", "")
        else:
            msg = getattr(chunk, "message", None)
            if msg:
                content_piece = getattr(msg, "content", "")
        
        if content_piece:
            yield content_piece


# -----------------------------------------------------------------------------
# 8. User Input & Streaming Execution
# -----------------------------------------------------------------------------
user_prompt = st.chat_input("Type your message... (Shift+Enter for newline)")

if user_prompt:
    # 1. Append user message to session history and display immediately
    st.session_state.messages.append({"role": "user", "content": user_prompt})
    
    with st.chat_message("user", avatar="🧑‍💻"):
        st.markdown(user_prompt)

    # 2. Prepare payload with full conversation history + system prompt
    payload = build_ollama_payload(st.session_state.messages, st.session_state.system_prompt)

    # 3. Stream assistant response with robust error handling
    with st.chat_message("assistant", avatar="🦙"):
        response_placeholder = st.empty()
        full_assistant_response = ""

        try:
            # Stream the assistant's response live
            with st.spinner(f"Thinking with {selected_model}..."):
                token_generator = stream_ollama_response(
                    model=selected_model,
                    messages_payload=payload,
                    temp=st.session_state.temperature
                )
                
                # Render stream in real time
                for token in token_generator:
                    full_assistant_response += token
                    response_placeholder.markdown(full_assistant_response + "▌")
                
                # Final flush without cursor
                response_placeholder.markdown(full_assistant_response)

            # Persist assistant's reply into session state
            if full_assistant_response:
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": full_assistant_response
                })

        except ollama.ResponseError as err:
            logger.error("Ollama ResponseError: %s", err)
            status_code = getattr(err, "status_code", None)
            
            if status_code == 404 or "not found" in str(err).lower():
                st.error(
                    f"❌ **Model `{selected_model}` was not found locally!**\n\n"
                    f"Please download the model via terminal:\n"
                    f"```bash\nollama pull {selected_model}\n```"
                )
            else:
                st.error(f"❌ **Ollama Error ({status_code or 'General'}):** {err.error if hasattr(err, 'error') else err}")

        except Exception as err:
            logger.error("Failed to communicate with Ollama: %s", err)
            st.error(
                "❌ **Could not connect to Ollama daemon.**\n\n"
                "**Troubleshooting Checklist:**\n"
                "1. **Is Ollama running?** Start it in your terminal: `ollama serve`\n"
                "2. **Is the port accessible?** Default is `http://localhost:11434`\n"
                "3. **Is the model installed?** Run `ollama list` or `ollama pull " + selected_model + "`\n"
                f"\n*Technical details: {str(err)}*"
            )
