import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  User,
  Send,
  Trash2,
  Sliders,
  Download,
  Copy,
  Check,
  RefreshCw,
  Terminal,
  FileCode,
  AlertCircle,
  CheckCircle2,
  Info,
  ExternalLink,
  Cpu,
  Sparkles,
  Play,
  Square,
  BookOpen,
  HelpCircle,
  Code,
  ShieldCheck,
  Layers,
  ChevronRight
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  modelUsed?: string;
}

const PRESET_PERSONAS: Record<string, string> = {
  'Python Mentor':
    'You are a Senior Python Architect and friendly coding mentor. Explain Python concepts concisely with PEP-8 compliant code examples, highlight best practices, modern Python 3.12+ features, type annotations, and edge cases.',
  'Senior Code Reviewer':
    'You are a meticulous Senior Software Engineer conducting a thorough code review. Critique code for algorithmic complexity, security vulnerabilities, readability, and idiomatic style. Provide refactored code snippets with step-by-step explanations.',
  'Concise Tech Assistant':
    'You are an ultra-concise technical assistant. Answer directly with minimal preamble. Prioritize bullet points, shell commands, and copy-pasteable code blocks.',
  'Socratic Tutor':
    'You are a Socratic tutor who helps engineers discover solutions through insightful guiding questions rather than immediately giving the full answer.',
  'General Assistant':
    'You are a helpful, brilliant, and precise AI assistant running locally via Ollama. Provide clear, accurate, and insightful answers with properly formatted code blocks where applicable.'
};

const DEFAULT_MODELS = [
  'llama3:latest',
  'mistral:latest',
  'phi3:latest',
  'deepseek-r1:latest',
  'gemma2:latest',
  'qwen2.5:latest'
];

const CODE_REQUIREMENTS = `# Production requirements for Local Ollama Chatbot with Streamlit
streamlit>=1.35.0
ollama>=0.2.1
python-dotenv>=1.0.1
`;

const CODE_APP_PY = `"""
================================================================================
Production-Ready Local Chatbot Web Application
Stack: Streamlit (Python) + Ollama (Python SDK) + python-dotenv
Features:
  - Dynamic ChatGPT-style Chat UI with User and Assistant messaging bubbles
  - Local AI engine via Ollama Python SDK with zero token costs and 100% privacy
  - Dynamic model discovery from local Ollama daemon (e.g., llama3, mistral, phi3)
  - Real-time streaming response generation
  - Multi-turn conversation memory preserved via Streamlit session state
  - System prompt customization with instant role-play presets (e.g., Python Mentor)
  - Comprehensive error handling for daemon offline or missing model states
================================================================================
"""

import os
import json
import logging
from typing import List, Dict, Any, Generator
import streamlit as st
import ollama
from dotenv import load_dotenv

# Load environment variables if configured in .env (e.g. OLLAMA_HOST)
load_dotenv()

# Configure basic logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# -----------------------------------------------------------------------------
# 1. Page Configuration & Custom CSS (ChatGPT-Inspired Aesthetics)
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="Ollama Local Chatbot",
    page_icon="🦙",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling for ChatGPT-style UI
CUSTOM_CSS = """
<style>
    /* Main container styling */
    .main .block-container {
        max-width: 900px;
        padding-top: 2rem;
        padding-bottom: 6rem;
    }

    /* Header title aesthetics */
    .app-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 1rem;
        border-bottom: 1px solid rgba(128, 128, 128, 0.2);
        margin-bottom: 1.5rem;
    }
    
    .app-title {
        font-size: 1.5rem;
        font-weight: 700;
        letter-spacing: -0.02em;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .app-subtitle {
        font-size: 0.85rem;
        color: #888888;
        margin-top: 0.2rem;
    }

    /* Status indicator */
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.2rem 0.6rem;
        border-radius: 9999px;
        background: rgba(16, 185, 129, 0.1);
        color: #10b981;
        border: 1px solid rgba(16, 185, 129, 0.25);
    }
    
    .status-badge-err {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.25);
    }

    .status-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background-color: currentColor;
    }

    /* Chat bubble enhancements */
    .stChatMessage {
        border-radius: 12px;
        padding: 0.75rem 1rem;
        margin-bottom: 0.75rem;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    }

    /* Sidebar controls */
    .sidebar-section-title {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-weight: 700;
        color: #888;
        margin-top: 1.25rem;
        margin-bottom: 0.5rem;
    }

    /* Pinned chat input styling */
    .stChatFloatingInputContainer {
        bottom: 1.5rem;
    }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


# -----------------------------------------------------------------------------
# 2. Session State Initialization
# -----------------------------------------------------------------------------
# Multi-turn conversation messages: list of {"role": "user"|"assistant", "content": "..."}
if "messages" not in st.session_state:
    st.session_state.messages = []

# Active system prompt (personality & behavioral instructions)
DEFAULT_SYSTEM_PROMPT = (
    "You are a helpful, brilliant, and precise AI assistant running locally via Ollama. "
    "Provide clear, accurate, and insightful answers with properly formatted code blocks where applicable."
)

if "system_prompt" not in st.session_state:
    st.session_state.system_prompt = DEFAULT_SYSTEM_PROMPT

# Default parameters
if "temperature" not in st.session_state:
    st.session_state.temperature = 0.7


# -----------------------------------------------------------------------------
# 3. Ollama Client & Dynamic Model Discovery
# -----------------------------------------------------------------------------
@st.cache_data(ttl=5)
def fetch_available_models() -> tuple[List[str], bool, str]:
    """
    Connect to local Ollama daemon and query the list of locally pulled models.
    Returns:
        tuple (models_list, is_connected, error_message)
    """
    try:
        ollama_host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
        client = ollama.Client(host=ollama_host)
        response = client.list()
        
        raw_models = response.get("models", []) if isinstance(response, dict) else getattr(response, "models", [])
        
        model_names = []
        for m in raw_models:
            if isinstance(m, dict):
                name = m.get("model") or m.get("name")
            else:
                name = getattr(m, "model", None) or getattr(m, "name", None)
            
            if name:
                model_names.append(name)
        
        if not model_names:
            return (
                ["llama3:latest", "mistral:latest", "phi3:latest"],
                True,
                "Connected to Ollama, but no models found locally. Run \`ollama pull <model>\` to download one."
            )
        
        return (sorted(model_names), True, "")
    except Exception as exc:
        err_msg = str(exc)
        logger.warning("Failed to connect to local Ollama daemon: %s", err_msg)
        fallback_models = ["llama3:latest", "mistral:latest", "phi3:latest", "deepseek-r1:latest"]
        return (fallback_models, False, err_msg)


# -----------------------------------------------------------------------------
# 4. Sidebar Controls & Customization
# -----------------------------------------------------------------------------
with st.sidebar:
    st.markdown("### 🦙 Ollama Local Engine")
    st.caption("Unlimited, 100% private, token-free AI on your hardware.")

    # Model Discovery & Connection Status
    available_models, is_ollama_connected, conn_error = fetch_available_models()

    if is_ollama_connected:
        st.markdown(
            '<div class="status-badge"><span class="status-dot"></span>Ollama Active (Local)</div>',
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            '<div class="status-badge status-badge-err"><span class="status-dot"></span>Ollama Disconnected</div>',
            unsafe_allow_html=True
        )
        st.warning(
            "⚠️ **Ollama is not running locally!**\\n\\n"
            "Please start the service in your terminal:\\n"
            "\`\`\`bash\\nollama serve\\n\`\`\`\\n"
            "Ensure Ollama is installed from [ollama.com](https://ollama.com)."
        )

    st.markdown('<div class="sidebar-section-title">Model Selector</div>', unsafe_allow_html=True)
    
    selected_model = st.selectbox(
        "Active Model:",
        options=available_models,
        index=0,
        help="Select any local model available in your Ollama library."
    )

    # System Prompt Customization
    st.markdown('<div class="sidebar-section-title">System Persona</div>', unsafe_allow_html=True)
    st.caption("Customize chatbot personality and instruction guidelines.")

    prompt_presets = {
        "Custom": st.session_state.system_prompt,
        "Python Mentor": (
            "You are a Senior Python Architect and friendly coding mentor. "
            "Explain Python concepts concisely with PEP-8 compliant code examples, "
            "highlight best practices, type annotations, and edge cases."
        ),
        "Code Reviewer": (
            "You are a meticulous Senior Software Engineer conducting a thorough code review. "
            "Critique code for performance, security vulnerabilities, readability, and idiomatic style. "
            "Provide refactored code snippets with explanations."
        ),
        "Concise Tech Assistant": (
            "You are an ultra-concise technical assistant. "
            "Answer directly with minimal preamble. Prioritize bullet points, shell commands, and copy-pasteable code."
        ),
        "General Assistant": DEFAULT_SYSTEM_PROMPT
    }

    preset_choice = st.selectbox(
        "Load Preset Persona:",
        options=list(prompt_presets.keys()),
        index=0
    )

    if preset_choice != "Custom":
        st.session_state.system_prompt = prompt_presets[preset_choice]

    system_prompt_input = st.text_area(
        "System Instructions:",
        value=st.session_state.system_prompt,
        height=130,
        help="These instructions are passed to Ollama on each turn to steer response behavior."
    )
    st.session_state.system_prompt = system_prompt_input

    # Generation Parameters
    st.markdown('<div class="sidebar-section-title">Generation Parameters</div>', unsafe_allow_html=True)
    temperature = st.slider(
        "Temperature (Creativity):",
        min_value=0.0,
        max_value=1.0,
        value=st.session_state.temperature,
        step=0.05,
        help="0.0 = Deterministic and precise. 1.0 = Creative and exploratory."
    )
    st.session_state.temperature = temperature

    # Action Buttons: Clear Chat & Export
    st.markdown('<div class="sidebar-section-title">Session Management</div>', unsafe_allow_html=True)
    
    col_clear, col_refresh = st.columns(2)
    with col_clear:
        if st.button("🗑️ Clear Chat", use_container_width=True):
            st.session_state.messages = []
            st.rerun()

    with col_refresh:
        if st.button("🔄 Refresh Models", use_container_width=True):
            st.cache_data.clear()
            st.rerun()

    # Conversation Export
    if st.session_state.messages:
        chat_export_json = json.dumps(
            {
                "model": selected_model,
                "system_prompt": st.session_state.system_prompt,
                "messages": st.session_state.messages
            },
            indent=2
        )
        st.download_button(
            label="📥 Export Chat (JSON)",
            data=chat_export_json,
            file_name="ollama_chat_history.json",
            mime="application/json",
            use_container_width=True
        )


# -----------------------------------------------------------------------------
# 5. Main UI Header
# -----------------------------------------------------------------------------
col_header_left, col_header_right = st.columns([3, 1])

with col_header_left:
    st.markdown(
        f"""
        <div class="app-header">
            <div>
                <h1 class="app-title">🦙 Ollama Local Chat</h1>
                <div class="app-subtitle">
                    Active Model: <strong>{selected_model}</strong> · Multi-turn context enabled · Zero API tokens
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

with col_header_right:
    msg_count = len(st.session_state.messages)
    st.metric(label="Conversation Turns", value=msg_count)


# -----------------------------------------------------------------------------
# 6. Render Existing Conversation History (Multi-turn persistence)
# -----------------------------------------------------------------------------
for msg in st.session_state.messages:
    role = msg.get("role", "user")
    content = msg.get("content", "")
    avatar = "🧑‍💻" if role == "user" else "🦙"
    
    with st.chat_message(role, avatar=avatar):
        st.markdown(content)


# -----------------------------------------------------------------------------
# 7. Helper: Build Message Payload with Multi-Turn Context & System Prompt
# -----------------------------------------------------------------------------
def build_ollama_payload(messages_history: List[Dict[str, str]], system_prompt: str) -> List[Dict[str, str]]:
    payload: List[Dict[str, str]] = []
    
    if system_prompt and system_prompt.strip():
        payload.append({
            "role": "system",
            "content": system_prompt.strip()
        })
        
    for msg in messages_history:
        payload.append({
            "role": msg["role"],
            "content": msg["content"]
        })
        
    return payload


def stream_ollama_response(
    model: str,
    messages_payload: List[Dict[str, str]],
    temp: float
) -> Generator[str, None, None]:
    ollama_host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    client = ollama.Client(host=ollama_host)
    
    response_stream = client.chat(
        model=model,
        messages=messages_payload,
        stream=True,
        options={
            "temperature": temp
        }
    )
    
    for chunk in response_stream:
        content_piece = ""
        if isinstance(chunk, dict):
            content_piece = chunk.get("message", {}).get("content", "")
        else:
            msg = getattr(chunk, "message", None)
            if msg:
                content_piece = getattr(msg, "content", "")
        
        if content_piece:
            yield content_piece


# -----------------------------------------------------------------------------
# 8. User Input & Streaming Execution
# -----------------------------------------------------------------------------
user_prompt = st.chat_input("Type your message... (Shift+Enter for newline)")

if user_prompt:
    st.session_state.messages.append({"role": "user", "content": user_prompt})
    
    with st.chat_message("user", avatar="🧑‍💻"):
        st.markdown(user_prompt)

    payload = build_ollama_payload(st.session_state.messages, st.session_state.system_prompt)

    with st.chat_message("assistant", avatar="🦙"):
        response_placeholder = st.empty()
        full_assistant_response = ""

        try:
            with st.spinner(f"Thinking with {selected_model}..."):
                token_generator = stream_ollama_response(
                    model=selected_model,
                    messages_payload=payload,
                    temp=st.session_state.temperature
                )
                
                for token in token_generator:
                    full_assistant_response += token
                    response_placeholder.markdown(full_assistant_response + "▌")
                
                response_placeholder.markdown(full_assistant_response)

            if full_assistant_response:
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": full_assistant_response
                })

        except ollama.ResponseError as err:
            logger.error("Ollama ResponseError: %s", err)
            status_code = getattr(err, "status_code", None)
            
            if status_code == 404 or "not found" in str(err).lower():
                st.error(
                    f"❌ **Model \`{selected_model}\` was not found locally!**\\n\\n"
                    f"Please download the model via terminal:\\n"
                    f"\`\`\`bash\\nollama pull {selected_model}\\n\`\`\`"
                )
            else:
                st.error(f"❌ **Ollama Error ({status_code or 'General'}):** {err.error if hasattr(err, 'error') else err}")

        except Exception as err:
            logger.error("Failed to communicate with Ollama: %s", err)
            st.error(
                "❌ **Could not connect to Ollama daemon.**\\n\\n"
                "**Troubleshooting Checklist:**\\n"
                "1. **Is Ollama running?** Start it in your terminal: \`ollama serve\`\\n"
                "2. **Is the port accessible?** Default is \`http://localhost:11434\`\\n"
                "3. **Is the model installed?** Run \`ollama list\` or \`ollama pull " + selected_model + "\`\\n"
                f"\\n*Technical details: {str(err)}*"
            )
`;

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'guide' | 'health'>('simulator');
  const [selectedCodeFile, setSelectedCodeFile] = useState<'app.py' | 'requirements.txt' | 'README.md'>('app.py');
  
  // Chat state
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      content:
        '👋 Welcome! I am your local AI assistant running through **Ollama** and **Streamlit**.\n\nAll interactions are **100% private**, run directly on local compute, and incur **zero API token costs**. You can customize my personality in the sidebar or ask anything!',
      timestamp: 'Just now',
      modelUsed: 'llama3:latest'
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [selectedModel, setSelectedModel] = useState<string>('llama3:latest');
  const [availableModels, setAvailableModels] = useState<string[]>(DEFAULT_MODELS);
  const [presetKey, setPresetKey] = useState<string>('Python Mentor');
  const [systemPrompt, setSystemPrompt] = useState<string>(PRESET_PERSONAS['Python Mentor']);
  const [temperature, setTemperature] = useState<number>(0.7);
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [streamingContent, setStreamingContent] = useState<string>('');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  
  // Connection / Diagnostic State
  const [ollamaHost, setOllamaHost] = useState<string>('http://localhost:11434');
  const [connectionStatus, setConnectionStatus] = useState<'checking' | 'connected' | 'offline' | 'sandbox'>('sandbox');
  const [simulatedErrorMode, setSimulatedErrorMode] = useState<'none' | 'offline' | 'model_missing'>('none');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingContent]);

  // Handle Preset change
  const handlePresetChange = (name: string) => {
    setPresetKey(name);
    if (name !== 'Custom') {
      setSystemPrompt(PRESET_PERSONAS[name]);
    }
  };

  // Test real local connection to Ollama if available
  const checkLocalOllamaConnection = async () => {
    setConnectionStatus('checking');
    try {
      // Query Ollama /api/tags
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      const res = await fetch(`${ollamaHost}/api/tags`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (res.ok) {
        const data = await res.json();
        if (data.models && Array.isArray(data.models) && data.models.length > 0) {
          const names = data.models.map((m: any) => m.name || m.model);
          setAvailableModels(names);
          if (!names.includes(selectedModel)) {
            setSelectedModel(names[0]);
          }
        }
        setConnectionStatus('connected');
      } else {
        setConnectionStatus('sandbox');
      }
    } catch {
      // Local daemon might be offline or blocked by browser CORS
      setConnectionStatus('sandbox');
    }
  };

  useEffect(() => {
    checkLocalOllamaConnection();
  }, [ollamaHost]);

  // Copy helper
  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(label);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Download file helper
  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Send message handler
  const handleSendMessage = async (textToSend?: string) => {
    const content = (textToSend || inputMessage).trim();
    if (!content || isStreaming) return;

    setInputMessage('');

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);

    // Check simulated error modes
    if (simulatedErrorMode === 'offline') {
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            role: 'assistant',
            content: `❌ **Could not connect to Ollama daemon.**\n\n**Troubleshooting Checklist:**\n1. **Is Ollama running?** Start it in your terminal:\n\`\`\`bash\nollama serve\n\`\`\`\n2. **Is the port accessible?** Default is \`http://localhost:11434\`\n3. **Is the model installed?** Run \`ollama list\` or \`ollama pull ${selectedModel}\`\n\n*(Error caught: Connection refused at ${ollamaHost})*`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            modelUsed: selectedModel
          }
        ]);
      }, 500);
      return;
    }

    if (simulatedErrorMode === 'model_missing') {
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            role: 'assistant',
            content: `❌ **Model \`${selectedModel}\` was not found locally!**\n\nPlease download the model via your terminal:\n\`\`\`bash\nollama pull ${selectedModel}\n\`\`\`\nThen click **Refresh Models** in the sidebar.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            modelUsed: selectedModel
          }
        ]);
      }, 500);
      return;
    }

    // Try live connection if available, otherwise high-fidelity local engine simulation
    setIsStreaming(true);
    setStreamingContent('');

    let realSuccess = false;
    if (connectionStatus === 'connected') {
      try {
        const fullPayload = [
          ...(systemPrompt ? [{ role: 'system', content: systemPrompt }] : []),
          ...messages.map((m) => ({ role: m.role, content: m.content })),
          { role: 'user', content }
        ];

        const response = await fetch(`${ollamaHost}/api/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: selectedModel,
            messages: fullPayload,
            stream: true,
            options: { temperature }
          })
        });

        if (response.ok && response.body) {
          realSuccess = true;
          const reader = response.body.getReader();
          const decoder = new TextDecoder();
          let fullText = '';

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n').filter(Boolean);
            for (const line of lines) {
              try {
                const parsed = JSON.parse(line);
                if (parsed.message?.content) {
                  fullText += parsed.message.content;
                  setStreamingContent(fullText);
                }
              } catch {
                // partial line
              }
            }
          }

          setMessages((prev) => [
            ...prev,
            {
              id: `asst-${Date.now()}`,
              role: 'assistant',
              content: fullText,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              modelUsed: selectedModel
            }
          ]);
          setStreamingContent('');
          setIsStreaming(false);
          return;
        }
      } catch (e) {
        console.warn('Direct Ollama connection attempt failed, falling back to local simulation:', e);
      }
    }

    // Fallback: Intelligent domain-aware simulator demonstrating multi-turn reasoning & personality
    const simulatedResponse = generateSimulatedResponse(content, systemPrompt, presetKey, selectedModel);
    
    // Simulate realistic streaming chunk by chunk
    const chunks = simulatedResponse.match(/.{1,12}/g) || [simulatedResponse];
    let accumulated = '';
    let i = 0;

    const interval = setInterval(() => {
      if (i < chunks.length) {
        accumulated += chunks[i];
        setStreamingContent(accumulated);
        i++;
      } else {
        clearInterval(interval);
        setMessages((prev) => [
          ...prev,
          {
            id: `asst-${Date.now()}`,
            role: 'assistant',
            content: accumulated,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            modelUsed: selectedModel
          }
        ]);
        setStreamingContent('');
        setIsStreaming(false);
      }
    }, 28);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setMessages([]);
    setShowClearConfirm(false);
  };

  const exportChatHistory = () => {
    const data = JSON.stringify(
      {
        model: selectedModel,
        system_prompt: systemPrompt,
        temperature,
        exported_at: new Date().toISOString(),
        messages
      },
      null,
      2
    );
    handleDownload('ollama_chat_export.json', data);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      {/* Top Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 h-14 bg-slate-900/90 backdrop-blur border-b border-slate-800 z-50 flex items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-lg">
            🦙
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm tracking-tight text-white">Ollama Local Chatbot</span>
              <span className="text-xs text-slate-400 hidden sm:inline">Streamlit + Ollama Python SDK</span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-400">
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Unlimited & Token-Free
              </span>
              <span>·</span>
              <span>Model: {selectedModel}</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md flex items-center gap-1.5 transition-colors ${
              activeTab === 'simulator'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Interactive Chat</span>
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md flex items-center gap-1.5 transition-colors ${
              activeTab === 'code'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Python Source</span>
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md flex items-center gap-1.5 transition-colors ${
              activeTab === 'guide'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Setup & Terminal</span>
          </button>
          <button
            onClick={() => setActiveTab('health')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md flex items-center gap-1.5 transition-colors ${
              activeTab === 'health'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Daemon Health</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="pt-14 w-full h-full flex overflow-hidden">
        {/* ========================================================================= */}
        {/* VIEW 1: INTERACTIVE CHATBOT (ChatGPT + Streamlit Experience) */}
        {/* ========================================================================= */}
        {activeTab === 'simulator' && (
          <div className="flex w-full h-full overflow-hidden">
            {/* Sidebar Controls (Streamlit-Style) */}
            <aside className="w-80 border-r border-slate-800/80 bg-slate-900/60 flex flex-col justify-between p-4 overflow-y-auto shrink-0">
              <div className="space-y-5">
                {/* Engine Status Header */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Engine Status</span>
                    {connectionStatus === 'connected' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                        Live Localhost
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                        <Cpu className="w-3 h-3" />
                        Local Sandbox
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400">
                    Ollama Python SDK runs directly on your hardware with unlimited context and zero cost.
                  </p>
                </div>

                {/* Model Selector */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-300">Model Selector</label>
                    <button
                      onClick={checkLocalOllamaConnection}
                      title="Refresh models from local daemon"
                      className="text-slate-400 hover:text-slate-200 transition-colors"
                    >
                      <RefreshCw className="w-3 h-3" />
                    </button>
                  </div>
                  <select
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500 transition-colors"
                  >
                    {availableModels.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-slate-500">
                    Supports any local model: llama3, mistral, phi3, deepseek-r1, gemma2.
                  </p>
                </div>

                {/* System Prompt Customization */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-300">System Persona Preset</label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {Object.keys(PRESET_PERSONAS).map((name) => (
                      <button
                        key={name}
                        onClick={() => handlePresetChange(name)}
                        className={`px-2.5 py-1.5 text-[11px] rounded-md text-left transition-colors font-medium truncate ${
                          presetKey === name
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-950 text-slate-400 border border-slate-800/80 hover:text-slate-200'
                        }`}
                      >
                        {name}
                      </button>
                    ))}
                  </div>

                  <div className="pt-1">
                    <label className="text-xs font-medium text-slate-400">System Instructions (On-the-fly)</label>
                    <textarea
                      rows={4}
                      value={systemPrompt}
                      onChange={(e) => {
                        setSystemPrompt(e.target.value);
                        setPresetKey('Custom');
                      }}
                      placeholder="e.g. Act as a Python Mentor who explains concepts with PEP-8 code..."
                      className="mt-1 w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-emerald-500 transition-colors resize-none leading-relaxed"
                    />
                  </div>
                </div>

                {/* Hyperparameters */}
                <div className="space-y-2 pt-1 border-t border-slate-800/60">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-300">Temperature</label>
                    <span className="text-xs font-mono text-emerald-400">{temperature.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={temperature}
                    onChange={(e) => setTemperature(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500">
                    <span>Precise (0.0)</span>
                    <span>Creative (1.0)</span>
                  </div>
                </div>

                {/* Test Error Handling (Demonstrating requirement #5) */}
                <div className="space-y-1.5 pt-2 border-t border-slate-800/60">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                    <span>Error Catch Simulator</span>
                  </label>
                  <p className="text-[11px] text-slate-400">
                    Test graceful failure modes required in production:
                  </p>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() =>
                        setSimulatedErrorMode(simulatedErrorMode === 'offline' ? 'none' : 'offline')
                      }
                      className={`px-2 py-1.5 text-[11px] rounded-md transition-colors font-medium ${
                        simulatedErrorMode === 'offline'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {simulatedErrorMode === 'offline' ? '✓ Ollama Offline' : 'Test: Daemon Offline'}
                    </button>
                    <button
                      onClick={() =>
                        setSimulatedErrorMode(simulatedErrorMode === 'model_missing' ? 'none' : 'model_missing')
                      }
                      className={`px-2 py-1.5 text-[11px] rounded-md transition-colors font-medium ${
                        simulatedErrorMode === 'model_missing'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {simulatedErrorMode === 'model_missing' ? '✓ Model 404' : 'Test: Missing Model'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Sidebar Footer Actions */}
              <div className="pt-4 border-t border-slate-800/80 space-y-2">
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowClearConfirm(true)}
                    className="flex-1 py-2 px-3 bg-slate-950 hover:bg-slate-800 text-slate-300 text-xs font-medium rounded-lg border border-slate-800 flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                    <span>Clear Chat</span>
                  </button>
                  <button
                    onClick={exportChatHistory}
                    disabled={messages.length === 0}
                    className="flex-1 py-2 px-3 bg-slate-950 hover:bg-slate-800 disabled:opacity-50 text-slate-300 text-xs font-medium rounded-lg border border-slate-800 flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Export JSON</span>
                  </button>
                </div>
                <div className="text-[10px] text-center text-slate-500">
                  Turns in session: {messages.length}
                </div>
              </div>
            </aside>

            {/* Main Chat Area (ChatGPT-Style) */}
            <main className="flex-1 flex flex-col justify-between h-full bg-slate-950 overflow-hidden relative">
              {/* Chat Messages List */}
              <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 space-y-6 max-w-4xl w-full mx-auto">
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 max-w-md mx-auto my-auto space-y-4">
                    <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-3xl">
                      🦙
                    </div>
                    <div>
                      <h2 className="text-lg font-semibold text-white">Local Ollama Ready</h2>
                      <p className="text-xs text-slate-400 mt-1">
                        Select an action below or type a message to start unlimited token-free multi-turn conversations.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 gap-2 w-full pt-2">
                      {[
                        'Teach me Python generators vs iterators with code examples',
                        'Review this function for memory leaks and performance',
                        'Write a clean FastAPI endpoint with Pydantic v2 validation',
                        'Explain how Ollama runs GGUF quantized models locally'
                      ].map((promptText, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSendMessage(promptText)}
                          className="p-2.5 text-xs text-left bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-300 hover:text-white transition-colors flex items-center justify-between group"
                        >
                          <span className="truncate">{promptText}</span>
                          <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 shrink-0 ml-2" />
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <>
                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex gap-3.5 ${
                          msg.role === 'user' ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        {/* Assistant Avatar */}
                        {msg.role === 'assistant' && (
                          <div className="w-8 h-8 rounded-lg bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-base shrink-0 mt-0.5">
                            🦙
                          </div>
                        )}

                        {/* Chat Bubble */}
                        <div
                          className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
                            msg.role === 'user'
                              ? 'bg-slate-800 text-slate-100 rounded-tr-xs border border-slate-700'
                              : 'bg-slate-900/90 text-slate-200 rounded-tl-xs border border-slate-800/80'
                          }`}
                        >
                          {/* Message Meta */}
                          <div className="flex items-center justify-between gap-4 mb-1 text-[11px] text-slate-500">
                            <span className="font-semibold text-slate-400">
                              {msg.role === 'user' ? 'You' : `Ollama (${msg.modelUsed || selectedModel})`}
                            </span>
                            <span>{msg.timestamp}</span>
                          </div>

                          {/* Content with Markdown code styling */}
                          <div className="prose prose-invert prose-sm max-w-none break-words">
                            <RenderMessageContent content={msg.content} onCopy={handleCopy} />
                          </div>
                        </div>

                        {/* User Avatar */}
                        {msg.role === 'user' && (
                          <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                            <User className="w-4 h-4" />
                          </div>
                        )}
                      </div>
                    ))}

                    {/* Live Streaming Bubble */}
                    {isStreaming && (
                      <div className="flex gap-3.5 justify-start">
                        <div className="w-8 h-8 rounded-lg bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-base shrink-0 mt-0.5">
                          🦙
                        </div>
                        <div className="max-w-[85%] rounded-2xl rounded-tl-xs px-4 py-3 text-sm leading-relaxed bg-slate-900/90 text-slate-200 border border-slate-800">
                          <div className="flex items-center gap-2 mb-1 text-[11px] text-emerald-400">
                            <Sparkles className="w-3 h-3 animate-spin" />
                            <span>Streaming tokens from {selectedModel}...</span>
                          </div>
                          <div className="prose prose-invert prose-sm max-w-none break-words">
                            <RenderMessageContent content={streamingContent} onCopy={handleCopy} />
                            <span className="inline-block w-2 h-4 bg-emerald-400 ml-1 animate-pulse align-middle" />
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Bottom Pinned Input Area */}
              <div className="p-4 bg-slate-950/95 border-t border-slate-800/80">
                <div className="max-w-4xl mx-auto space-y-2">
                  <div className="relative flex items-end bg-slate-900 border border-slate-800 rounded-xl focus-within:border-emerald-500/80 focus-within:ring-1 focus-within:ring-emerald-500/50 transition-all shadow-inner">
                    <textarea
                      ref={textareaRef}
                      rows={1}
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="Message your local Ollama... (Press Enter to send, Shift+Enter for newline)"
                      className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-sm px-4 py-3 max-h-32 focus:outline-none resize-none leading-relaxed"
                    />

                    <div className="p-2 shrink-0">
                      <button
                        onClick={() => handleSendMessage()}
                        disabled={!inputMessage.trim() || isStreaming}
                        className="w-8 h-8 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 disabled:hover:bg-emerald-500 text-slate-950 flex items-center justify-center transition-colors font-semibold"
                        title="Send message"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 px-1">
                    <div className="flex items-center gap-2">
                      <span>Persona: <strong className="text-slate-400">{presetKey}</strong></span>
                      <span>·</span>
                      <span>Temp: <strong className="text-slate-400">{temperature}</strong></span>
                    </div>
                    <span>No data leaves your machine · Powered by Ollama</span>
                  </div>
                </div>
              </div>
            </main>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: PYTHON SOURCE CODE (Production Streamlit app.py & requirements) */}
        {/* ========================================================================= */}
        {activeTab === 'code' && (
          <div className="flex w-full h-full bg-slate-950 overflow-hidden">
            {/* File Sidebar */}
            <div className="w-64 border-r border-slate-800 bg-slate-900/50 p-4 flex flex-col justify-between shrink-0">
              <div className="space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Project Files
                </div>
                <div className="space-y-1">
                  <button
                    onClick={() => setSelectedCodeFile('app.py')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-mono transition-colors text-left ${
                      selectedCodeFile === 'app.py'
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    }`}
                  >
                    <FileCode className="w-4 h-4 text-emerald-400" />
                    <span>app.py</span>
                  </button>

                  <button
                    onClick={() => setSelectedCodeFile('requirements.txt')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-mono transition-colors text-left ${
                      selectedCodeFile === 'requirements.txt'
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    }`}
                  >
                    <FileCode className="w-4 h-4 text-cyan-400" />
                    <span>requirements.txt</span>
                  </button>

                  <button
                    onClick={() => setSelectedCodeFile('README.md')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-mono transition-colors text-left ${
                      selectedCodeFile === 'README.md'
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    }`}
                  >
                    <BookOpen className="w-4 h-4 text-amber-400" />
                    <span>README.md</span>
                  </button>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-400 space-y-2">
                  <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Key Architecture</span>
                  </div>
                  <p>
                    • <code className="text-emerald-400">ollama.chat(stream=True)</code> with message array preserves multi-turn memory.
                  </p>
                  <p>
                    • <code className="text-emerald-400">st.session_state.messages</code> maintains history across rerenders.
                  </p>
                  <p>
                    • Dynamic discovery via <code className="text-emerald-400">ollama.list()</code>.
                  </p>
                </div>
              </div>

              {/* 1-Click Download Actions */}
              <div className="space-y-2 pt-4 border-t border-slate-800">
                <button
                  onClick={() => {
                    const content =
                      selectedCodeFile === 'app.py'
                        ? CODE_APP_PY
                        : selectedCodeFile === 'requirements.txt'
                        ? CODE_REQUIREMENTS
                        : '# Readme in repo';
                    handleDownload(selectedCodeFile, content);
                  }}
                  className="w-full py-2 px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs rounded-lg flex items-center justify-center gap-2 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download {selectedCodeFile}</span>
                </button>
              </div>
            </div>

            {/* Code Content Viewer */}
            <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-950">
              <div className="h-10 border-b border-slate-800 flex items-center justify-between px-4 bg-slate-900/40">
                <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-600"></span>
                  <span>/{selectedCodeFile}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      const content =
                        selectedCodeFile === 'app.py'
                          ? CODE_APP_PY
                          : selectedCodeFile === 'requirements.txt'
                          ? CODE_REQUIREMENTS
                          : '# Readme in repo';
                      handleCopy(content, selectedCodeFile);
                    }}
                    className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-100 px-2.5 py-1 rounded bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 transition-colors"
                  >
                    {copiedCode === selectedCodeFile ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy File Content</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-300 leading-relaxed bg-slate-950">
                <pre className="overflow-x-auto whitespace-pre">
                  <code>
                    {selectedCodeFile === 'app.py'
                      ? CODE_APP_PY
                      : selectedCodeFile === 'requirements.txt'
                      ? CODE_REQUIREMENTS
                      : `# Setup instructions available in terminal guide.`}
                  </code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: SETUP & TERMINAL GUIDE */}
        {/* ========================================================================= */}
        {activeTab === 'guide' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Complete Setup & Deployment Guide
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Follow these step-by-step instructions to run your Streamlit + Ollama application locally.
              </p>
            </div>

            {/* Step 1 */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-md bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center justify-center">
                  1
                </div>
                <h3 className="text-sm font-semibold text-white">Install and Start Ollama</h3>
              </div>
              <p className="text-xs text-slate-400">
                Ollama runs local LLMs (Llama 3, Mistral, Phi-3, DeepSeek-R1) via GGUF quantization. Download the installer for your OS:
              </p>
              <div className="flex gap-2">
                <a
                  href="https://ollama.com/download"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 border border-slate-700 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download Ollama for macOS / Windows / Linux</span>
                </a>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 font-mono text-xs text-slate-300 space-y-1">
                <div className="text-slate-500"># Verify Ollama service and download your desired models</div>
                <div>ollama --version</div>
                <div>ollama pull llama3</div>
                <div>ollama pull mistral</div>
                <div>ollama pull phi3</div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-md bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center justify-center">
                  2
                </div>
                <h3 className="text-sm font-semibold text-white">Prepare Python Virtual Environment</h3>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 font-mono text-xs text-slate-300 space-y-1">
                <div className="text-slate-500"># Create virtual environment</div>
                <div>python3 -m venv venv</div>
                <div className="text-slate-500 mt-2"># Activate on macOS/Linux:</div>
                <div>source venv/bin/activate</div>
                <div className="text-slate-500 mt-2"># Or activate on Windows PowerShell:</div>
                <div>.\venv\Scripts\Activate.ps1</div>
                <div className="text-slate-500 mt-2"># Install dependencies</div>
                <div>pip install -r requirements.txt</div>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-md bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center justify-center">
                  3
                </div>
                <h3 className="text-sm font-semibold text-white">Launch the Streamlit Web Application</h3>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 font-mono text-xs text-slate-300 space-y-1">
                <div className="text-slate-500"># Run the full-stack app</div>
                <div>streamlit run app.py</div>
              </div>
              <p className="text-xs text-slate-400">
                Streamlit will open <code className="text-emerald-400">http://localhost:8501</code> in your browser automatically.
              </p>
            </div>

            {/* Pro-Tip: Enabling CORS if connecting remote / web */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">Pro-Tip: Ollama CORS Configuration</h3>
              </div>
              <p className="text-xs text-slate-400">
                If you ever want web apps or browser extensions to connect directly to your local Ollama port (<code className="text-slate-300">11434</code>), launch Ollama with the origins flag:
              </p>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 font-mono text-xs text-slate-300 space-y-1">
                <div className="text-slate-500"># macOS / Linux terminal:</div>
                <div>OLLAMA_ORIGINS="*" ollama serve</div>
                <div className="text-slate-500 mt-2"># Windows PowerShell:</div>
                <div>$env:OLLAMA_ORIGINS="*" ; ollama serve</div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 4: LOCAL DAEMON HEALTH CHECK */}
        {/* ========================================================================= */}
        {activeTab === 'health' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Local Ollama Health Diagnostics
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Real-time connection tester to inspect local Ollama daemon status and installed models.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-300">Target Daemon Host</div>
                  <div className="text-[11px] text-slate-500">Default is http://localhost:11434</div>
                </div>
                <button
                  onClick={checkLocalOllamaConnection}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Ping Host</span>
                </button>
              </div>

              <input
                type="text"
                value={ollamaHost}
                onChange={(e) => setOllamaHost(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-emerald-500"
              />

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="text-[11px] text-slate-500">Status</div>
                  <div className="text-sm font-semibold mt-1 flex items-center gap-1.5">
                    {connectionStatus === 'connected' ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Connected
                      </span>
                    ) : connectionStatus === 'checking' ? (
                      <span className="text-cyan-400 flex items-center gap-1">
                        <RefreshCw className="w-4 h-4 animate-spin" /> Pinging...
                      </span>
                    ) : (
                      <span className="text-amber-400 flex items-center gap-1">
                        <Cpu className="w-4 h-4" /> Sandbox Mode
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="text-[11px] text-slate-500">Active Model</div>
                  <div className="text-sm font-mono font-semibold text-white mt-1 truncate">
                    {selectedModel}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="text-[11px] text-slate-500">Available Models Count</div>
                  <div className="text-sm font-mono font-semibold text-emerald-400 mt-1">
                    {availableModels.length} models ready
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                <div className="text-xs font-semibold text-slate-300">Installed Models in Library:</div>
                <div className="flex flex-wrap gap-1.5">
                  {availableModels.map((m) => (
                    <span
                      key={m}
                      className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300"
                    >
                      {m}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Clear Chat Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 max-w-sm w-full space-y-4 shadow-xl">
            <div className="flex items-center gap-2.5 text-rose-400">
              <Trash2 className="w-5 h-5" />
              <h3 className="font-semibold text-white text-sm">Clear Conversation History?</h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              This will reset the chat history in session state. All conversation context for multi-turn turns will be cleared.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={clearChat}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-600 hover:bg-rose-500 text-white transition-colors"
              >
                Clear History
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// -----------------------------------------------------------------------------
// Helper Component: Message Content Renderer with Code Blocks
// -----------------------------------------------------------------------------
function RenderMessageContent({
  content,
  onCopy
}: {
  content: string;
  onCopy: (text: string, label: string) => void;
}) {
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-2">
      {parts.map((part, index) => {
        if (part.startsWith('```') && part.endsWith('```')) {
          const firstLineEnd = part.indexOf('\n');
          const lang = part.substring(3, firstLineEnd).trim() || 'text';
          const codeBody = part.substring(firstLineEnd + 1, part.length - 3);

          return (
            <div
              key={index}
              className="my-3 rounded-lg overflow-hidden border border-slate-800 bg-slate-950 font-mono text-xs"
            >
              <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-800 text-[11px] text-slate-400">
                <span>{lang}</span>
                <button
                  onClick={() => onCopy(codeBody, `block-${index}`)}
                  className="hover:text-white flex items-center gap-1 transition-colors"
                >
                  <Copy className="w-3 h-3" />
                  <span>Copy code</span>
                </button>
              </div>
              <pre className="p-3 overflow-x-auto text-emerald-300/90 leading-relaxed">
                <code>{codeBody}</code>
              </pre>
            </div>
          );
        }

        // Render plain text with line breaks and markdown bold
        const lines = part.split('\n');
        return (
          <div key={index} className="space-y-1">
            {lines.map((line, lIdx) => {
              if (line.startsWith('### ')) {
                return (
                  <h4 key={lIdx} className="font-bold text-white text-sm mt-2">
                    {line.replace('### ', '')}
                  </h4>
                );
              }
              if (line.startsWith('## ')) {
                return (
                  <h3 key={lIdx} className="font-bold text-white text-base mt-3">
                    {line.replace('## ', '')}
                  </h3>
                );
              }
              if (line.startsWith('• ') || line.startsWith('- ')) {
                return (
                  <div key={lIdx} className="flex gap-2 pl-2 text-slate-300">
                    <span className="text-emerald-400">•</span>
                    <span>{parseBold(line.substring(2))}</span>
                  </div>
                );
              }
              if (!line.trim()) {
                return <div key={lIdx} className="h-1" />;
              }
              return (
                <p key={lIdx} className="text-slate-200">
                  {parseBold(line)}
                </p>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

function parseBold(text: string): React.ReactNode {
  const segments = text.split(/(\*\*.*?\*\*|`.*?`)/g);
  return segments.map((seg, i) => {
    if (seg.startsWith('**') && seg.endsWith('**')) {
      return (
        <strong key={i} className="font-semibold text-white">
          {seg.slice(2, -2)}
        </strong>
      );
    }
    if (seg.startsWith('`') && seg.endsWith('`')) {
      return (
        <code
          key={i}
          className="px-1.5 py-0.5 rounded bg-slate-800 text-emerald-300 font-mono text-[11px]"
        >
          {seg.slice(1, -1)}
        </code>
      );
    }
    return seg;
  });
}

// -----------------------------------------------------------------------------
// Realistic domain-aware simulation generator when local daemon is not running
// -----------------------------------------------------------------------------
function generateSimulatedResponse(
  prompt: string,
  systemPrompt: string,
  persona: string,
  model: string
): string {
  const pLower = prompt.toLowerCase();

  if (pLower.includes('generator') || pLower.includes('iterator')) {
    return `### Python Generators vs Iterators\n\nGreat question! In Python, all **generators** are iterators, but not all iterators are generators.\n\n### 1. The Key Difference\n- **Iterator**: Any object that implements the iterator protocol (\`__iter__()\` and \`__next__()\`).\n- **Generator**: A function that produces a sequence of values lazily using the \`yield\` keyword.\n\n\`\`\`python
from typing import Iterator

def count_up_to(limit: int) -> Iterator[int]:
    """Generator function that produces numbers lazily."""
    current = 1
    while current <= limit:
        yield current
        current += 1

# Lazy evaluation consumes O(1) memory
gen = count_up_to(5)
for number in gen:
    print(number)  # Yields 1, 2, 3, 4, 5
\`\`\`\n\n### Why use Generators?\n• **Memory Efficiency**: Values are computed on-demand rather than loaded into RAM all at once.\n• **Infinite Streams**: Ideal for reading large log files or streaming sensors.\n• **Clean Syntax**: No need to manually manage state in class attributes!`;
  }

  if (pLower.includes('fastapi') || pLower.includes('endpoint') || pLower.includes('crud')) {
    return `### Production FastAPI + Pydantic v2 Snippet\n\nHere is a clean, type-annotated endpoint pattern following modern FastAPI best practices:\n\n\`\`\`python
from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field
from typing import Dict, Optional

app = FastAPI(title="Item Service", version="1.0.0")

class ItemCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    price: float = Field(..., gt=0)
    in_stock: bool = True

class ItemResponse(ItemCreate):
    id: int

# In-memory database simulation
db: Dict[int, ItemResponse] = {}

@app.post("/items", response_model=ItemResponse, status_code=status.HTTP_201_CREATED)
async def create_item(payload: ItemCreate) -> ItemResponse:
    item_id = len(db) + 1
    item = ItemResponse(id=item_id, **payload.model_dump())
    db[item_id] = item
    return item
\`\`\`\n\nNotice the use of \`model_dump()\` (Pydantic v2 replacement for \`.dict()\`) and proper status code enums.`;
  }

  if (pLower.includes('review') || persona === 'Senior Code Reviewer') {
    return `### Code Review Insights\n\nHere is a critique based on idiomatic standards and performance:\n\n1. **Type Annotations**: Always declare explicit parameter types and return signatures for maintainability.\n2. **Complexity**: Check loops for unnecessary memory allocation (\`list()\` copying vs lazy generator).\n3. **Exception Handling**: Avoid bare \`except:\` clauses; catch specific errors (e.g. \`KeyError\`, \`ValueError\`).\n\n\`\`\`python
# Refactored idiomatic pattern
def process_records(records: list[dict]) -> dict[str, int]:
    return {rec["id"]: rec["score"] for rec in records if "score" in rec}
\`\`\`\n\nWould you like me to analyze a specific snippet from your codebase?`;
  }

  return `### Response from ${model}\n\nI have received your request:\n> "${prompt}"\n\n**Active System Persona (${persona}):**\nI am configured to respond according to your custom instructions:\n*"${systemPrompt.slice(0, 100)}..."*\n\nHere is what you need to know:\n• **Zero Token Fees**: Running locally means no API rate limits or recurring costs.\n• **Context Retention**: Previous turns in this conversation are preserved and supplied in the \`messages\` payload.\n• **High Performance**: Ollama optimizes local inference on Apple Silicon (Metal) and Nvidia GPUs (CUDA).\n\nFeel free to ask a follow-up or test another prompt!`;
}
